=======================================================
JUNKYARD BUILDER JunkyardModManager - v1.0.0
=======================================================
Author: BroGamerYT

The ultimate in-game Mod Manager and automatic updater for Junkyard Builder! Manage and update all your mods in-game via F1.

INSTALLATION (DEUTSCH):
1. Kopiere die JunkyardModManager.dll in deinen 'Junkyard Builder/Mods' Ordner.
2. Starte das Spiel.

INSTALLATION (ENGLISH):
1. Copy JunkyardModManager.dll into your 'Junkyard Builder/Mods' folder.
2. Launch the game.
