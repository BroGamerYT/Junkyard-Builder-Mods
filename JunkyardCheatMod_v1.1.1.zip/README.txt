=======================================================
JUNKYARD BUILDER JunkyardCheatMod - v1.1.1
=======================================================
Author: BroGamerYT

The ultimate in-game Cheat Box for Junkyard Builder! Geld, XP, Laufgeschwindigkeit, Lieferzeit-Slider und Sofort-Zerkleinern via F2.

INSTALLATION (DEUTSCH):
1. Kopiere die JunkyardCheatMod.dll in deinen 'Junkyard Builder/Mods' Ordner.
2. Starte das Spiel.

INSTALLATION (ENGLISH):
1. Copy JunkyardCheatMod.dll into your 'Junkyard Builder/Mods' folder.
2. Launch the game.
