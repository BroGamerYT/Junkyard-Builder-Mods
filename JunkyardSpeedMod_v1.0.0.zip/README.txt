=======================================================
JUNKYARD BUILDER JunkyardSpeedMod - v1.0.0
=======================================================
Author: BroGamerYT

Control the entire game speed in Junkyard Builder using customizable hotkeys (Num+, Num-, Num*).

INSTALLATION (DEUTSCH):
1. Kopiere die JunkyardSpeedMod.dll in deinen 'Junkyard Builder/Mods' Ordner.
2. Starte das Spiel.

INSTALLATION (ENGLISH):
1. Copy JunkyardSpeedMod.dll into your 'Junkyard Builder/Mods' folder.
2. Launch the game.
