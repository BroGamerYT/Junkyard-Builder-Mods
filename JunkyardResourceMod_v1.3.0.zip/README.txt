=======================================================
JUNKYARD BUILDER JunkyardResourceMod - v1.3.0
=======================================================
Author: BroGamerYT

Configure scrap delivery amounts, yard capacities, contract payouts and unlock all upgrades instantly in Junkyard Builder.

INSTALLATION (DEUTSCH):
1. Kopiere die JunkyardResourceMod.dll in deinen 'Junkyard Builder/Mods' Ordner.
2. Starte das Spiel.

INSTALLATION (ENGLISH):
1. Copy JunkyardResourceMod.dll into your 'Junkyard Builder/Mods' folder.
2. Launch the game.
