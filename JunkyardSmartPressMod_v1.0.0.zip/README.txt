=======================================================
JUNKYARD BUILDER JunkyardSmartPressMod - v1.0.0
=======================================================
Author: BroGamerYT

Ultimate scrap press, baler and shredder optimization for Junkyard Builder! Automatic weight buffering (no lost scrap), continuous insertion (always open green hopper), smart-fill triggers, auto-insertion and instant compression.

INSTALLATION (DEUTSCH):
1. Kopiere die JunkyardSmartPressMod.dll in deinen 'Junkyard Builder/Mods' Ordner.
2. Starte das Spiel.

INSTALLATION (ENGLISH):
1. Copy JunkyardSmartPressMod.dll into your 'Junkyard Builder/Mods' folder.
2. Launch the game.
