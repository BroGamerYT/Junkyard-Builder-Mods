=======================================================
JUNKYARD BUILDER JunkyardWeightMod - v1.0.0
=======================================================
Author: BroGamerYT

Double your carrying capacity and wheelbarrow weight limits in Junkyard Builder.

INSTALLATION (DEUTSCH):
1. Kopiere die JunkyardWeightMod.dll in deinen 'Junkyard Builder/Mods' Ordner.
2. Starte das Spiel.

INSTALLATION (ENGLISH):
1. Copy JunkyardWeightMod.dll into your 'Junkyard Builder/Mods' folder.
2. Launch the game.
